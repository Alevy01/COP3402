To compile:
	- Navigate to folder which holds source code VM0.c
	- Compile using gcc VM0.c -o vm
	- Run compiled file using ./vm
	- Input is read from file mcode.txt
	- Output will be in file stacktrace.txt
	- Output example is based off of the mcode.txt included in the zip